<?php

$con=mysqli_connect("localhost","root","","university");
if(mysqli_connect_error())
{
   die("عذراً لدينا بعض المشاكل في الاتصال بالسيرفر");
}
$id=$_POST['id'];
$pas=$_POST['pass'];
$query="SELECT * FROM students WHERE id='$id' AND pass='$pas'";
$res=mysqli_query($con,$query);
$row=mysqli_fetch_array($res);
if(!$row)
{
    die("الرقم الجامعي او كلمة المرور غير صحيحه ");
    header("refrech:2; url='signStudent.html'");
    
}
else
{
   echo "welcome mr ".$row['name'];
}
?>