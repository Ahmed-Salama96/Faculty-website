<?php
$con=mysqli_connect("localhost","root","");
if(!$con){
   die("connection error");
        }
if(!mysqli_select_db($con,"university"))
{
    echo "cannot select data base";
}
$name=$_POST['name'];
$phone=$_POST['phone'];
$add=$_POST['add'];
$date=$_POST['date'];
$email=$_POST['email'];
//$cv =$_POST['cv'];
$six=$_POST['six'];
$text=$_POST['text'];
$q="INSERT INTO workers(name , phone , address , email , six , textarea , birth) VALUES ('$name','$phone','$add','$email','$six','$text','$date')";
if(!mysqli_query($con,$q))
{
    echo "cannot insert".$name;
}
else
{
    echo "inserted";
}
?>