<!DOCTYPE html>
<html lang="ar" dir="rtl">
 <head>
    <meta charset="utf-8">
    <title>الهيكل التنظيمي</title>
    <link href="style.css" type="text/css" rel="stylesheet">
    </head>
 <body>
     <div class="lang"> 
          <ul class="nav">
            <li><a href="" class="en">En</a></li>
             <li><a href="" class="ar">ع</a></li>
            <li><a href="home.html">الرئيسية</a></li>
            <li><a href="about-us.html">عن الكلية </a></li>
            <li><a href="contact.html">اتصل بنا </a></li>
            <li><a href="">خريطة الموقع </a></li>
              <li><a href="https://www.alexu.edu.eg">موقع الجامعة </a></li>
            </ul>
              <input type="search" class="search" placeholder="عن ماذا تبحث ؟ " >
              <input type="image" src="search.png" onclick="" id="subSrch">
          </div>
           <h1>مرحباً بك في البروفايل الخاص بك </h1>
     <div id="stMenu">hello </div>
    </body>
</html>