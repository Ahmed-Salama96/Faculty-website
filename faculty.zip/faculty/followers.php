<?php
 
 $con = mysqli_connect("localhost","root","","university");
  if(mysqli_connect_error())
  {
      die("sorry we have some errors ");
      
      
  }
$email=$_POST['email'];
$q="SELECT email FROM followers ";
if(!$res = mysqli_query($con,$q))die("عفوا لايمكنك الاشتراك الان , من فضلك اعد الاشتراك في وقت لاحق");
$row = mysqli_fetch_array($res);
$check = false;
foreach($row as $temp)
{
    if($email === $temp )
        $check = true;
}
if($check == true) {
    die("لقد قمت بالتسجيل من قبل ..شكراً لاهتمامك ");
    
}

$query="INSERT INTO followers(email) VALUES('$email')";
if(!mysqli_query($con,$query))
{
    echo "عفوا لايمكنك الاشتراك الان , من فضلك اعد الاشتراك في وقت لاحق";
    
}
else
 echo 'مرحا بك لقد تم الاشتراك بنجاح الان سوف يصلك كل جديد عن الكلية  ';
header("refresh:2, url=home.html");
?>